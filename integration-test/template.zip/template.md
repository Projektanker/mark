
::: text-center  
for

$customer.name$  
$customer.address1$  
$customer.address2$  
("Customer")

:::

## Paragraph 1

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque molestie dui ac dolor interdum, in ultrices libero eleifend. Quisque vitae ligula eget enim vehicula molestie eget in orci. Cras vel nibh velit. Sed tempus tortor a nibh rutrum, id venenatis felis viverra. Pellentesque eu metus non est feugiat feugiat dignissim nec lacus. Sed eget libero dictum, aliquet libero sed, semper lacus. Integer at scelerisque erat. Cras neque nibh, blandit vel volutpat non, posuere ac massa. Curabitur vitae purus sed risus imperdiet volutpat.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a tortor mi. Nulla eget ex quam. Aliquam feugiat lacinia massa, eget dictum erat lobortis vitae. Cras eu nulla malesuada, cursus metus suscipit, rutrum erat. Praesent aliquam viverra erat, vitae fringilla lacus. Vestibulum ultricies dolor ut eros posuere tempus. Quisque lacinia purus eget lectus egestas tempus. Suspendisse consequat, velit sed efficitur condimentum, nunc mauris fermentum ipsum, quis maximus ipsum ante sed odio. Sed molestie maximus vestibulum. Nulla nunc metus, lacinia et volutpat in, auctor eget diam. Duis et auctor neque. Vestibulum finibus ex a lacus interdum rhoncus. Phasellus eros mauris, convallis eu tempor id, feugiat a velit.

Etiam volutpat odio a nulla pulvinar, at volutpat libero elementum. Sed in mattis diam. Duis urna elit, rutrum in purus non, egestas dictum lectus. Aliquam et augue interdum, tincidunt purus non, lobortis erat. Praesent maximus volutpat scelerisque. Proin id odio finibus, consectetur ligula rutrum, venenatis arcu. Pellentesque in lacus eu metus vestibulum viverra. Nam odio purus, placerat vitae nisi molestie, pharetra sollicitudin ipsum. Sed non sem mauris.

Aenean eu gravida tortor. Etiam tempor mi varius consequat ultrices. Aliquam blandit non leo et pretium. Donec at facilisis diam. Vestibulum vitae magna eu augue feugiat pulvinar. Morbi id erat lectus. Phasellus vel felis vitae urna dignissim semper. Integer sodales nunc nec volutpat tincidunt. Cras commodo sapien non eleifend sagittis. Pellentesque eu purus magna.

Cras ornare nunc leo, quis tempor quam dapibus vel. Nulla dapibus quam rutrum efficitur iaculis. Etiam eleifend quis nibh at porta. Vivamus id nunc et tortor tristique auctor. Etiam maximus eros eget neque cursus venenatis. Maecenas sed enim mattis, aliquam sem eu, auctor mauris. Phasellus fringilla pulvinar neque vel vestibulum. Curabitur nec augue cursus, laoreet diam vitae, hendrerit tortor. Donec auctor suscipit urna, id suscipit velit pulvinar non. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Sed placerat hendrerit nisl, vitae mattis ipsum pellentesque at. Aliquam in egestas orci. Integer aliquam vehicula nulla eu dignissim. Mauris maximus ullamcorper justo rutrum tristique. Morbi libero odio, ullamcorper a lobortis non, auctor non magna. 

## Paragraph 2

Phasellus fringilla pulvinar neque vel vestibulum:

- Lorem ipsum dolor sit amet, consectetur adipiscing elit.
- Aliquam quis diam lobortis, ullamcorper enim sed, vestibulum justo.
- Nullam at odio commodo, rhoncus nisi eget, sodales erat.
- Etiam elementum ipsum ut turpis sollicitudin tincidunt.
- Nulla ultricies ipsum et cursus volutpat.
- Nullam vitae orci eleifend, congue tortor eu, scelerisque lorem.


## Paragraph 3

Lorem ipsum dolor sit amet:

1. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
2. Aliquam quis diam lobortis, ullamcorper enim sed, vestibulum justo.
3. Nullam at odio commodo, rhoncus nisi eget, sodales erat.
